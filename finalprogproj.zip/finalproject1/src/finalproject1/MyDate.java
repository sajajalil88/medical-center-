package finalproject1;



public class MyDate {
	private String day ;
	private int month;
	private double begHour ;
	public MyDate()
	{
		
	}
	public MyDate(int month,String day,double begHour )
	{
		if(month >=1 && month <=12)
			this.month = month ;
		else
			this.month = 1;
		if(day.equalsIgnoreCase("monday")
				|| day.equalsIgnoreCase("tuesday")
				|| day.equalsIgnoreCase("wednesday")
				||day.equalsIgnoreCase("thursday")
				|| day.equalsIgnoreCase("friday"))
			this.day = day ; 
		else 
			 this.day = "monday";
		
		if(begHour >8.0 && begHour <16.0 )
			this.begHour = begHour ;
		else
			this.begHour = 8.00 ;

	}
	public String getDay()
	{
		return this.day ;
	}
	public double getBegHour()
	{
		return this.begHour ;
	}
	
	public String getMonth()
	{
		String[] month = {"Jan",	"Feb",	"Mar",	"Apr",	"May",	"Jun",	"Jul",	"Aug",	"Sep",	"Oct",	"Nov",	"Dec"};
		return month[this.month-1];
	}
	public void setDay(String newDay)
	{
		if(newDay.equalsIgnoreCase("monday")
				|| newDay.equalsIgnoreCase("tuesday")
				|| newDay.equalsIgnoreCase("wednesday")
				||newDay.equalsIgnoreCase("thursday")
				|| newDay.equalsIgnoreCase("friday"))
			this.day = newDay ; 
		else 
			 System.out.println("Sorry,we're closed in this day ");
	}
	public void setBegHour(double newBegHour)
	{
		if(newBegHour >8 )
			this.begHour = newBegHour ;
		else
			System.out.println("Sorry, we're not opened yet ");
	}
	public void setMonth(int newMonth)
	{
		if(newMonth>=1 && newMonth<=12)
			this.month = newMonth ;
		else
			System.out.println("Error: invalid monthh");
	}
	public String toString()
	{
	   String date = " ";
		String[] month = {"Jan",	"Feb",	"Mar",	"Apr",	"May",	"Jun",	"Jul",	"Aug",	"Sep",	"Oct",	"Nov",	"Dec"};
		date+=  "["+this.day+"]["+(month[this.month-1])+"][2022] at "+ this.begHour  ;
		if(this.begHour>12)
			date += " pm" ;
		else
			date += " am" ;
		return date ;
	}
    

}
