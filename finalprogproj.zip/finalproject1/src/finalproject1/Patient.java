package finalproject1;


public class Patient extends Person {
	
	private String symptom ;
	public Patient(String fname,String lname,String symptom ,int age,boolean isVaccinated)
	{
		super(fname,lname,age,isVaccinated);
		this.symptom= symptom ;
	}
    public String getSymptom()
    {
    	return this.symptom ;
    }
    public void setSymptom(String newSymptom)
    {
    	this.symptom = newSymptom ;
    }
    public String toString()
    {
    	String patient = "";
    	patient += super.toString();
    	patient += "\tSymptom : " + this.symptom ;
    	return patient ;
    }
    public boolean equals(Object otherPatient)
    {
       if(this== otherPatient)
    	   return true ;
       if(otherPatient == null || getClass()!= otherPatient.getClass())
    	   return false ;
       
       Patient p = (Patient) otherPatient;
       return (this.getFirstName()== p.getFirstName()
    		   && this.getLastName()== p.getLastName()
    		   && this.getAge() == p.getAge()
    		   && this.getSymptom() == p.getSymptom()
    		   && this.getIssVaccinated() == p.getIssVaccinated());
    }
	

}