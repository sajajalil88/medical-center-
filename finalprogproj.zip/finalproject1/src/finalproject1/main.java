package finalproject1;
import java.io.PrintWriter;
import java.util.Scanner ;
import java.util.ArrayList;

public class main {
	
     public static void main(String[] args)
     {
    	 Scanner scan = new Scanner(System.in);
    	 // variables 
    	 int choice=0, choice1=0,choice2=0,choice3 =0, choice4=0 ;
    	 int count=0;
    	 String fname,lname,degree, speciality;
    	 int age, yearsOfExperience,month, newMonth;
    	 int doctorAge , newDoctorAge;
    	 int patientAge, newPatientAge ;
    	 String month2;
    	 double begHour, newBegHour ;
    	 boolean isVaccinated,patientIsVaccinated,doctorIsVaccinated, newPatientIsVaccinated, newDoctorIsVaccinated;
    	 String doctorFirstName,newDoctorFirstName, doctorLastName, newDoctorLastName, doctorSpecialty, newDoctorSpecialty, day,newDay, patientFirstName, newPatientFirstName,patientLastName, newPatientLastName , patientSymptom, newPatientSymptom  ;
    	 // calling classes 
    	 Jobs CV = new Jobs() ;
    	 Job job = null;
    	 Job acc ;
    	 MyDate date2 = null ;
    	 Appointment appointment=null ;
    	 Clinic clinic = new Clinic() ;
    	 Doctor doctor = null;
    	 Patient patient = null;
    	 Vaccination vacc  = new Vaccination();
    	 Medicine medicine = new Medicine();
    	 Medicine medicines = null ;
    	 Medicine[] meds =  {
    		 new Medicine("OC001","Advil",15,1,4),
    		 new Medicine("OC111","Panadol",30,1,3),
    		 new Medicine("OC301","Dapsone",25,1,4),
    		 new Medicine("ODO01","Fidaxomi",45,1,4),
    		 new Medicine("OPP00","Hydralazi",37,1,4),
    		 new Medicine("PR455","Metronida",15,1,4),
    		 new Medicine("ST200","Potassium",34,1,4),
    		 new Medicine("QC331","Cefaclor",25,1,6),
    		 new Medicine("Bb852","Morphine",55,13,15),
    		 new Medicine("K1003","Modafinil",30,1,5),
    	 };
    	 while(choice != 5)
    	 {
    	 System.out.println("Hello and welcome to our medical center ");
    	 System.out.println("Please choose what you are searching for from the below given menu :\n1-Apply your CV here \n2-Patients \n3 Vaccination \n4-Pharmacy \n5-Exit");
    	 choice = scan.nextInt();
    	 scan.nextLine();
    	 switch(choice)
    	 {
    	 
    	 
    		 case 1:
    			 count++;
    			 for(int i = 0 ; i < count ; i++)
    			 System.out.println("");
 			    System.out.println("enter your first name :");
			    fname = scan.nextLine();
			    System.out.println("enter your last name :");
			    lname = scan.nextLine();
			    System.out.println("enter your age :");
			    age = scan.nextInt();
			    System.out.println("Are you vaccinated :");
			    isVaccinated = scan.nextBoolean();
			    scan.nextLine();
			    System.out.println("enter your degree in Med-School(master , bachelor , doctoral):");
			    degree = scan.nextLine();
			    System.out.println("enter your speciality :");
			    speciality = scan.nextLine();
			    System.out.println("enter your years of experience  : ");
			    yearsOfExperience= scan.nextInt();
			    scan.nextLine();
			    job= new Job(fname,lname,age,isVaccinated,degree,speciality,yearsOfExperience);
			    acc= new Job(fname,lname,age,isVaccinated,degree,speciality,yearsOfExperience);
			    CV.add(job);
			    System.out.println("Save all Appointments to CSV file...");
	     		WriteToCSV(CV);
    			 
			    System.out.println("Hello, the answer of the application that you applied to our medical center with the following data\n"+ acc);
			    if(acc.isaccepted())
			    {
			    	System.out.println("You Got Accepted !");
			    	System.out.println("Now your information will be added to join our team, Welcome !!");	
			    }
    			 
			    else
			    {
			    	System.out.println("Sorry, Better luck in another places");
			    }
			    
    			 
		       break;
		       
    	  case 2:
    		  while(choice3 != 4)
    		  {
    	   System.out.println("For Appointments, choose what you want from the below list : \n1-Add Appointment \n2-Edit Patient Info \n3-Edit Doctor Info \n4-Exit ");
    	   choice3=scan.nextInt();
    	   scan.nextLine();
    	   switch(choice3)
    	   {
    	   case 1: 
    		   count++;
    		   System.out.println("answer the following questions to add your appointment : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter your symptom : ");
    		   patientSymptom =scan.nextLine();
    		   System.out.println("enter your age : ");
    		   patientAge=scan.nextInt();
    		   scan.nextLine();
    		   System.out.println("enter your vaccination state:(true or false boolean value) ");
    		   patientIsVaccinated= scan.nextBoolean() ;
    		   scan.nextLine();
    		   
    		   //polymorphism by inheritance 
    		  System.out.println("here are the doctors that are not in service right now :");
    		  Person p1 = new Doctor("Maroun","Abi Assaf","general",35,true);
    		  Person p2 = new Doctor("Marie","Saade","dermatoligist",65,false);
    		  Person p3 = new Doctor("Hamsa","Hasrouny","pediatrics",70,true);
    		  Person p4 = new Doctor("Mohmmad","Rida","orthopedics",45,true);
    		  Person p5 = new Doctor("Elie","Abu joude","radiology",35,true);
    		  Person p6 = new Doctor("Mohmmad","Rida","orthopedics",45,true);
    		  
    		  ArrayList<Person>  doctors = new ArrayList<Person>();
    		  
    		  doctors.add(p1);
    		  doctors.add(p2);
    		  doctors.add(p3);
    		  doctors.add(p4);
    		  doctors.add(p5);
    		  doctors.add(p6);
    		 
    		 for(Person doctorsoutofservice : doctors)
    		 {
    			 System.out.println(doctorsoutofservice);
    		 }
    		  
    		   System.out.println("enter your doctor name : ");
    		   doctorFirstName = scan.nextLine();
    		   System.out.println("enter your doctor last name : ");
    		   doctorLastName=scan.nextLine();
    		   System.out.println("enter your doctor speciality : ");
    		   doctorSpecialty=scan.nextLine();
    		   System.out.println("enter your doctor age : ");
    		   doctorAge = scan.nextInt();
    		   System.out.println("enter your doctor vaccination state :(true or false boolean value) ");
    		   doctorIsVaccinated = scan.nextBoolean();
    		   System.out.println("enter the month that you want to take your appointment at as integer  : ");
    		   month = scan.nextInt();
    		   System.out.println("enter the day that you want to take your appointment at : \n1-monday\n2-tuesday\n3-wednesday\n4-thursday\n5-friday\n ");
    		   scan.nextLine();
    		   day=scan.nextLine();
    		   System.out.println("enter the time(24 hour time) you want to take the appointment at : ");
    		   begHour = scan.nextDouble();
    		   scan.nextLine();
			   appointment = new Appointment(patientFirstName,patientLastName,patientSymptom,patientAge,patientIsVaccinated,doctorFirstName,doctorLastName,doctorSpecialty,doctorAge,doctorIsVaccinated,month,day,begHour);
    		   clinic.add(appointment);
    		   System.out.println("Save all Appointments to CSV file...");
     		   WriteToCSV(clinic);
    		   break;
    		   
    		   
    	   case 2 :
    		   
    		   while(choice2!=10)
    		   {
    		   System.out.println("Edit Patient info list : "
       	  		+ "\n1-Search for appointment "
       	  		+ "\n2-Modify your first name "
       	  		+ "\n3-Modify your last name "
       	  		+ "\n4-Modify your age "
       	  		+ "\n5-Modify your vaccination State"
       	  		+ "\n6-Modify your symptom"
       	  		+ "\n7-Modify the day of your Appointment "
       	  	    + "\n8-Delete Appointment "
       	  		+ "\n9-Print all Appointments"
       	  		+ "\n10-Exit");
    	   choice2 = scan.nextInt();
    	   scan.nextLine();
    	   switch(choice2)
    	   { 
    	   case 1:
    		   System.out.println("Search for your Doctor : " );
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   patient =clinic.searchAppointment(patientFirstName, patientLastName);
				  if(patient != null)
					  System.out.println(patient);
				  else
					  System.out.println("Error: appointment does not exist!");
				      System.out.println();
    		   break;
    	   case 2:
    		   System.out.println("Modify your first name : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter the your new first name: ");
    		   newPatientFirstName= scan.nextLine();
    		   clinic.editPatientFirstName(patientFirstName, patientLastName, newPatientFirstName);
    		   break;
    	   case 3:
    		   System.out.println("Modify your last name : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter the your new last name: ");
    		   newPatientLastName= scan.nextLine();
    		   clinic.editPatientLastName(patientFirstName, patientLastName, newPatientLastName);
    		   break;
    	   case 4:
    		   System.out.println("Modify your age : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter the your new age: ");
    		   newPatientAge= scan.nextInt();
    		   scan.nextLine();
    		   clinic.editPatientAge(patientFirstName, patientLastName, newPatientAge);
    		   break;
    	   case 5:
    		   System.out.println("Modify your vaccination state : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter the your new vaccination state: ");
    		   newPatientIsVaccinated= scan.nextBoolean();
    		   scan.nextLine();
    		   clinic.editPatientVaccination(patientFirstName, patientLastName, newPatientIsVaccinated);
    		   break;
    	   case 6:
    		   System.out.println("Modify your symptom : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   System.out.println("enter the your new symptom name: ");
    		   newPatientSymptom= scan.nextLine();
    		   scan.nextLine();
    		   clinic.editPatientSymptom(patientFirstName, patientLastName, newPatientSymptom);
    		   break;
    	   case 7:
    		   System.out.println("Modify the Date of your appointment : ");
    		   System.out.println("Search for your Doctor : " );
    		   System.out.println("enter the your intitial month: ");
    		   month2= scan.nextLine();
    		   System.out.println("enter the your intitial day: ");
    		   day= scan.nextLine();
    		   System.out.println("enter the your intitial time: ");
    		   begHour= scan.nextDouble();
    		   scan.nextLine();
    		   date2 =clinic.searchDate(month2,day,begHour);
				  if(date2 != null)
				  {
					  System.out.println("enter your newDay");
					  newDay=scan.nextLine();
					  System.out.println("enter your newMonth");
					  newMonth = scan.nextInt();
					  scan.nextLine();
					  System.out.println("enter your new begHour");
					  newBegHour=scan.nextDouble();
					  scan.nextLine();
					 clinic.editDate(month2, day, begHour, newMonth, newDay, newBegHour);
				  }
				      else
					  System.out.println("Error: appointment does not exist!");
				      System.out.println();
    		   break;
    		   
    	   case 8:
    		   System.out.println("Delete your appointment  : ");
    		   System.out.println("enter the your first name: ");
    		   patientFirstName= scan.nextLine();
    		   System.out.println("enter the your last name: ");
    		   patientLastName= scan.nextLine();
    		   clinic.deleteAppointment(patientFirstName, patientLastName);
    		   break;
    	   case 9:
    		   System.out.println(clinic);
    		   break;
    	   case 10:
    		   break;
    	  default:
    		  System.out.println("invalid input");
    		  break;
    	   }
    		   }
    		 break;  
    	   case 3:
    		   while(choice3!=7)
    		   {
    		   System.out.println("Edit Doctor info list : "
    	       	  		+ "\n1-Search for appointment "
    	       	  		+ "\n2-Modify Doctor first name "
    	       	  		+ "\n3-Modify Doctor last name "
    	       	  		+ "\n4-Modify Doctor age "
    	       	  		+ "\n5-Modify Doctor vaccination State"
    	       	  		+ "\n6-Modify Doctor speciality"
    	       	  		+ "\n7-Exit");
    	    	   choice3 = scan.nextInt();
    	    	   scan.nextLine();
    	    	   switch(choice3)
    	    	   { 
    	    	   case 1:
    	    		   System.out.println("Search for Doctor you reserved at  : " );
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   doctor =clinic.searchDoctor(doctorFirstName,doctorLastName);
    					  if(doctor != null)
    						  System.out.println(doctor);
    					  else
    						  System.out.println("Error: Doctor does not exist!");
    					      System.out.println();
    	    		   break;
    	    	   case 2:
    	    		   System.out.println("Modify Doctor first name : ");
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   System.out.println("enter the your new first name: ");
    	    		   newDoctorFirstName= scan.nextLine();
    	    		   clinic.editDoctorFirstName(doctorFirstName, doctorLastName, newDoctorFirstName);
    	    		   break;
    	    	   case 3:
    	    		   System.out.println("Modify Doctor last name : ");
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   System.out.println("enter the your new last  name: ");
    	    		   newDoctorLastName= scan.nextLine();
    	    		   clinic.editDoctorLastName(doctorFirstName, doctorLastName, newDoctorLastName);
    	    		   break;
    	    	   case 4:
    	    		   System.out.println("Modify Doctor age : ");
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   System.out.println("enter the your new age: ");
    	    		   newDoctorAge= scan.nextInt();
    	    		   scan.nextLine();
    	    		   clinic.editDoctorAge(doctorFirstName, doctorLastName, newDoctorAge);
    	    		   break;
    	    	   case 5:
    	    		   System.out.println("Modify Doctor vaccination state : ");
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   System.out.println("enter the your new vaccination state: ");
    	    		   newDoctorIsVaccinated= scan.nextBoolean();
    	    		   scan.nextLine();
    	    		   clinic.editDoctorVaccination(doctorFirstName, doctorLastName, newDoctorIsVaccinated);
    	    		   break;
    	    	   case 6:
    	    		   System.out.println("Modify Doctor speciality : ");
    	    		   System.out.println("enter the your first name: ");
    	    		   doctorFirstName= scan.nextLine();
    	    		   System.out.println("enter the your last name: ");
    	    		   doctorLastName= scan.nextLine();
    	    		   System.out.println("enter the your new speciality: ");
    	    		   newDoctorSpecialty= scan.nextLine();
    	    		   scan.nextLine();
    	    		   clinic.editDoctorSpeciality(doctorFirstName, doctorLastName, newDoctorSpecialty);
    	    		   break;
    	    	  
    	    	   case 7:
    	    		   break;
    	    		default:
    	    			System.out.println("invalid input ");
    	    			break;
    	    	   }  
    		   }
    		   break;
    	   case 4:
    		   break;
    		   
     }
    	   break;
    	 }
    		  break;
    	  case 3:
    		 
    		  
    		  vacc.Greet();
    		  vacc.Wait(); 
    		  System.out.println("please enter your full name");
    		  String name = scan.nextLine();
    		 
    		  System.out.println("please enter your age:");
    		  age = scan.nextInt();
    		  System.out.println("Do you suffer from any symptoms ?? (true or false)");
    		  boolean isAny = scan.nextBoolean();
    		  
    		  if( vacc.CanVaccine(age , isAny))
    		  {
    			  System.out.println("YOU can take the vaccination , which dose u want to take? (1 0r 2 )");
    			  int dose = scan.nextInt();
    			   if(dose == 1)
    			  {
    				  vacc.VaccinationCost1();
    			  }
    			   else if(dose == 2)
    			   {
    				   vacc.VaccinationCost2();
    			   }
    			   else
    			   {
    				   System.out.println("error");
    			   }
    		
    			   vacc.Leave();
    			 
    		  }
    		  else
    		  {
    			  System.out.println("sorry , you cannot take the vaccination!\n\n");
    		  }
    		break ;
    		
    	  case 4 :
    		 medicine.Greet();
    		 medicine.Wait();
    		 
    		 System.out.println("Do you want to get a \n 1-medicine  \n 2-calculate your BMI \n 3-exit??");
    		 int ch = scan.nextInt();
    		 
    		 switch(ch)
    		 {
    	  case 1 :
    		  
				int repeat;
				do {
    			for(int i = 0 ; i<10 ; i++)
    			{
    				System.out.println(meds[i]);
    			}
    		 
    		 System.out.println("enter the name and code of the medicine that you are searching for:");
    		 String medName = scan.next();
    		 String medCode = scan.next();
    		 Medicine temp = null ; 
    		boolean found = false ; 
    		for(int i = 0 ; i<10 ; i++)
    		{
    			if(meds[i].Name.equalsIgnoreCase(medName)&& meds[i].Code.equalsIgnoreCase(medCode))
    			{
    				temp = meds[i];
    				found = true ;
    			}
    		}
    		if(found)
    		{
    			System.out.println(temp.toString());
    		
    		System.out.println("The medicine costs"+ temp.getPrice());
    		System.out.println("Do you want to purchase it (1 for yes , 0 for no )??");
    		int purchase = scan.nextInt();
    		if(purchase == 1)
    		{
    			System.out.println("Do you have any .... Discount card ??(1 for yes , 0 for no )");
    			int answer = scan.nextInt();
    			if(answer == 1)
    			{
    				double newPrice = temp.getPrice() - ( temp.getPrice()*0.02) ;
    				System.out.println("Your new payment must be :"+newPrice + "  after 20% discount");
    				medicine.Leave();
    			}
    			else if(answer == 0)
    			{
    				System.out.println("The medicine still costs"+ temp.getPrice()); 
    				medicine.Leave();
    			}
    		}
    			else if(purchase == 0 )
    			{
    				medicine.Leave();
    			}
    		}
    		
    			else
        		{
        			System.out.println("Medicine not found");
        			
        		}
    		
    		
    		System.out.println("do u want to repeat(1 for yes , 0 for no ) ?");
    		 repeat = scan.nextInt();
    		  }while(repeat == 1);
				break;
    	  case 2 :
    		  double w , h ; 
    		  System.out.println("enter ur weight:");
    		  w = scan.nextDouble();
    		  System.out.println("enter ur height:");
    		  h = scan.nextDouble();
    		  
    		  medicine.getBMI(w, h);
    		  
    		  medicine.Leave();
    		  break;
    	  case 3 :
    		  System.out.println("Exit...");
     		   break;
    		  default:
    		System.out.println("error");
    		 
    		 
    		 } 
    		 break ;  
    	  case 5:
   		   System.out.println("Exit...");
   		   break;
   	    default:
   		   System.out.println("Error");
   		   break;
    	 }
    	 
    	 }
    	
    	 }
     public static void WriteToCSV(Clinic clist) {
    	 
    	 Appointment [] appointments=clist.getAppointments();
 	    int appLength=appointments.length;
 		
		 try (PrintWriter writer = new PrintWriter("appointment.csv")) {
		      StringBuilder file = new StringBuilder();		
		String DELIMITER=",";
		String SEPARATOR="\n";
		String HEADER = "Patient name ,last name,age,Is Vaccinated,Symptom,Doctor name ,last name,age,Is Vaccinated,Speciality,Month,Day,Time)";
				
		//Add header
		file.append(HEADER);		
		file.append(SEPARATOR);
		
		
		//iterate through computerList
		for(int i=0; i<appLength; i++)
		{
			
			if(appointments[i]!=null) {
		
		
			file.append(appointments[i].getPatient().getFirstName());
			file.append(DELIMITER);
			
			file.append(appointments[i].getPatient().getLastName()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getPatient().getAge()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getPatient().getIssVaccinated()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getPatient().getSymptom()+"");				
			file.append(DELIMITER);

			file.append(appointments[i].getDoctor().getFirstName());
			file.append(DELIMITER);
			
			file.append(appointments[i].getDoctor().getLastName()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getDoctor().getAge()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getDoctor().getIssVaccinated()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getDoctor().getSpeciality()+"");				
			file.append(DELIMITER);
			file.append(appointments[i].getDate().getMonth()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getDate().getDay()+"");				
			file.append(DELIMITER);
			
			file.append(appointments[i].getDate().getBegHour()+"");				
			file.append(DELIMITER);
			file.append(SEPARATOR);
			
			}
		}
		 writer.write(file.toString());

	      System.out.println("File Created Successfuly!");
	
	}
	
	catch(Exception e) {
		e.printStackTrace();
			
		}
	}
   public static void WriteToCSV(Jobs clist) {
    	 
    	 Job [] jobs=clist.getJobs();
 	    int jobslength=jobs.length;
 		
		 try (PrintWriter writer = new PrintWriter("jobs.csv")) {
		      StringBuilder file = new StringBuilder();		
		String DELIMITER=",";
		String SEPARATOR="\n";
		String HEADER = "CV name ,last name,age,Is Vaccinated,Degree,speciality ,exp years)";
				
		//Add header
		file.append(HEADER);		
		file.append(SEPARATOR);
		
		
		//iterate through computerList
		for(int i=0; i<jobslength; i++)
		{
			
			if(jobs[i]!=null) {
		
		
			file.append(jobs[i].getFirstName());
			file.append(DELIMITER);
			
			file.append(jobs[i].getLastName()+"");				
			file.append(DELIMITER);
			
			file.append(jobs[i].getAge()+"");				
			file.append(DELIMITER);
			
			file.append(jobs[i].getIssVaccinated()+"");				
			file.append(DELIMITER);
			
			file.append(jobs[i].getDegree()+"");				
			file.append(DELIMITER);

			file.append(jobs[i].getSpeciality());
			file.append(DELIMITER);
			
			file.append(jobs[i].getYearOfExperience()+"");				
			file.append(DELIMITER);
			file.append(SEPARATOR);
			
			}
		}
		 writer.write(file.toString());

	      System.out.println("File Created Successfuly!");
	
	}
	
	catch(Exception e) {
		e.printStackTrace();
			
		}
	}
     }
    	
     



