package finalproject1;


public class Doctor extends Person {
	private String speciality ;
	public Doctor(String fname,String lname,String speciality ,int age,boolean isVaccinated)
	{
		super(fname,lname,age,isVaccinated);
		this.speciality= speciality ;
	}
    public String getSpeciality()
    {
    	return this.speciality ;
    }
    public void setSpeciality(String newSpeciality)
    {
    	this.speciality = newSpeciality ;
    }
    public String toString()
    {
    	String patient = "";
    	patient += super.toString();
    	patient += "\tSpeciality: " + this.speciality ;
    	return patient ;
    }
    public boolean equals(Object otherDoctor)
    {
       if(this== otherDoctor)
    	   return true ;
       if(otherDoctor == null || getClass()!= otherDoctor.getClass())
    	   return false ;
       
       Doctor d = (Doctor) otherDoctor;
       return (this.getFirstName()== d.getFirstName()
    		   && this.getLastName()== d.getLastName()
    		   && this.getAge() == d.getAge()
    		   && this.getSpeciality() == d.getSpeciality()
    		   && this.getIssVaccinated() == d.getIssVaccinated());
    }
	


}