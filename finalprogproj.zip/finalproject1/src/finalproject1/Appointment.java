package finalproject1;



public class Appointment  {

	private Patient patient ;
	private Doctor doctor ;
	private MyDate date ;
	
	Appointment(String patientFirstName, String patientLastName, String patientSymptom, int patientAge, boolean patientIsVaccinated,String doctorFirstName, String doctorLastName, String doctorSpecialty,int doctorAge, boolean doctorIsVaccinated,int month, String day, double begHour)
	{
		this.patient = new Patient(patientFirstName,patientLastName,patientSymptom,patientAge,patientIsVaccinated);
        this.doctor = new Doctor(doctorFirstName, doctorLastName, doctorSpecialty, doctorAge,doctorIsVaccinated);
	    this.date = new MyDate(month,day,begHour);
	}
	Appointment (Patient patient, Doctor doctor,MyDate date)
	{
		this.patient = patient ;
		this.doctor = doctor ;
		this.date = date ;
	}
	public Patient getPatient()
	{
		return this.patient;
	}
	public Doctor getDoctor()
	{
		return this.doctor ;
	}
	public MyDate getDate()
	{
		return this.date ;
	}
	public void setPatient(Patient newPatient)
	{
		this.patient = newPatient ;
	}
	public void setDoctor(Doctor newDoctor)
	{
		this.doctor = newDoctor ;
	}
	public void setDate(MyDate newDate)
	{
		this.date = newDate ;
	}
	public String toString()
	{
		String appointment ="";
		appointment += this.patient ;
		appointment += this.doctor ;
		appointment += this.date ;
		return appointment ;
	}
	
}