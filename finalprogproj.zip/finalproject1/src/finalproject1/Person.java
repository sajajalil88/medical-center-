package finalproject1;


public abstract class Person {
    private String firstName ;
    private String lastName ;
    private int age ;
    private boolean isVaccinated ;
    
    public Person(String fname,String lname,int age,boolean isVaccinated)
    {
    	this.firstName = fname ;
    	this.lastName =lname ;
    	if(age>0)
    	this.age = age ;
    	else
    	this.age = 0 ;
    	if(isVaccinated==true || isVaccinated == false )
    	this.isVaccinated = isVaccinated ;
    	else
    	this.isVaccinated = false ;
    }
    public String getFirstName()
    {
    	return this.firstName;
    }
    public String getLastName()
    {
    	return this.lastName;
    }
    public int getAge()
    {
    	return this.age;
    }
    public boolean getIssVaccinated()
    {
    	return this.isVaccinated;
    }
    public void setFirstName(String newFirstName)
    {
    	this.firstName = newFirstName;
    }
    public void setLastName(String newLastName)
    {
    	this.lastName= newLastName;
    }
    public void setAge(int newAge)
    {
    	this.age = newAge;
    }
    public void setIsVaccinated(boolean newIsVaccinated)
    {
    	this.isVaccinated = newIsVaccinated ;
    }
    public String toString()
    {
    	String info ="";
    	info += "name : " + this.firstName +" "+ this.lastName+ "\t" ;
    	info += "age :" + this.age +"\t" ;
    	info += "vaccination State : " + this.isVaccinated ;
    	return info ;
   	}
    
}