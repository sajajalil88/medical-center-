package finalproject1;

import java.text.DecimalFormat ;

public class Medicine implements VaccPharm {
	
	public String Code ;
	public String Name ;
	public double Price ; 
	public int MinDose ;
	public int MaxDose ;
	public double weight ;
	public double height ;

	DecimalFormat dm = new DecimalFormat("0.###");
	
	public Medicine()
	{
		
	}
	public void Greet()
	{
		System.out.println("welcome to our Pharmacy :");
	
	}
	public void Wait()
	{
		System.out.println("Ok come here and wait in the line for about " + Math.floor((Math.random()*12)+3) + " minutes.");
	}
	public Medicine(String Code , String Name , double Price,int MinDose , int MaxDose  )
	{
		this.Code = Code ; 
		this.Name = Name ;
		this.Price = Price ; 
		this.MinDose = MinDose ; 
		this.MaxDose = MaxDose ;
	}
	
	
	 public double getBMI(double weight , double height)
	 {
		 double bmi ; 
		 bmi = ((weight) / Math.pow((height / 100),2));
		 
		 System.out.println("your bmi is :" + dm.format(bmi));
		 if(bmi < 18)
		 {
			 System.out.println("You are underWeight");
		 }
		 else if( bmi  >= 18.5 || bmi <= 24.5)
		 {
			 System.out.println("You are normal");
		 }
		 else if(bmi < 25)
		 {
			 System.out.println("You are overWeight");
		 }
		 else
		 {
			 System.out.println("error");
		 }
		 return bmi ;
	 }
	public void setCode(String newCode)
	{
		this.Code = newCode ;
	}
	public void setName(String newName)
	{
		this.Name = newName ;
	}
	
	public void setPrice(double newPrice)
	{
		this.Price = newPrice ;
	}
	public void setminDose(int newMinDose)
	{
		this.MinDose = newMinDose ; 
	}
	public void setaxDose(int newMaxDose)
	{
		this.MaxDose = newMaxDose ; 
	}
	public String getCode() {
		return this.Code ; 
	}
	
	public String getName() {
		return this.Name ; 
	}
	
	public double getPrice()
	{
		return this.Price ;
	}
	public int getminDose()
	{
		return this.MinDose  ;
	}
	public int getmaxDose()
	{
		return this.MaxDose ; 
	}
	
	public  void VaccinationCost1()
	{
		
	}
	public void VaccinationCost2()
	{
		
	}
	
	public void Leave()
	{
		System.out.println("Thank you for your visit! have a nice day \n");
	}
	public String toString()
	{
		String res = "";
		res += "Code:"+this.Code +"\tName:"+this.Name + "\tPrice:"+this.Price + "\tmaxDose:"+this.MaxDose + "\tminDose:"+this.MinDose  ;

		return res ;
	}
	

}
