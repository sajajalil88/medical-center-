package finalproject1;



public class Job extends Person{
	private String degree , speciality ; 
	private int yearOfExperience ; 
	
	
	public Job(String fname,String lname,int age,boolean isVaccinated,String degree , String speciality ,int yearOfExperience )
	{

		super(fname,lname,age,isVaccinated);
		this.degree = degree ; 
	    this.speciality = speciality;
		if(yearOfExperience >0  )
			this.yearOfExperience = yearOfExperience ;
		else
			this.yearOfExperience = 0 ;
			
	}
	public boolean isaccepted()
	{
	
		 return((this.yearOfExperience>=3)&& ((this.degree.equalsIgnoreCase("master")||this.degree.equalsIgnoreCase("doctoral")||this.degree.equalsIgnoreCase("bachelor"))));
	}
	public String getDegree()
	{
		return this.degree ; 
	}
	public String getSpeciality()
	{
		return this.speciality ;
	}
	public int getYearOfExperience()
	{
		return this.yearOfExperience ;
	}
	public void setSpeciality(String newSpeciality)
	{
		this.speciality = newSpeciality ;
	
	}
	public void setDegree(String newDegree)
	{

		if(newDegree.equalsIgnoreCase("Master")|| newDegree.equalsIgnoreCase("Doctoral")|| newDegree.equalsIgnoreCase("bachelor"))
				this.degree = newDegree ;
		
		else 
			System.out.println("error!"); 
		
	}
	public void setYearOfExperience(int yearOfExperience)
	{
		if(yearOfExperience >= 3 )
			this.yearOfExperience = yearOfExperience ;
		else
			System.out.println("error!");  
	}
	
	public String toString()
	{
		String job="" ; 
		job += super.toString();
		job += "\tDegree: "+this.degree + "\nSpeciality: "+this.speciality + "\t Years of experience : "+this.yearOfExperience ;
		return job ;
	}


}
