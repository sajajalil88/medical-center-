package finalproject1;


public interface VaccPharm {

	public abstract void Greet();
	public abstract void Wait();
	public abstract void Leave();
	public abstract void VaccinationCost1();
	public abstract void VaccinationCost2();
	
}
