package finalproject1;


public class Vaccination implements VaccPharm {

	private String fname ;
	private String lname ; 
	private int age ; 
	private boolean Anysymptoms ;

	
	public void Greet()
	{
		System.out.println("welcome to our vaccination part:");
	
	}
	public void Wait()
	{
		System.out.println("Ok come here and wait in the line for about " + Math.floor((Math.random()*15)+3) + " minutes.");
	}
	public Vaccination()
	{
		
	}
	public Vaccination(String fname , String lname , int age , boolean Anysymptoms )
	{
		this.fname = fname ; 
		this.lname = lname ; 
		this.age = age ; 
		this.Anysymptoms = Anysymptoms ; 
	}
	public void setFName(String fname ) {
		this.fname = fname ; 
	
	}
	public void setLName(String lname ) {
		this.lname = lname ; 
	
	}
	public void setAge(int age) {
		this.age = age ; 
	
	}
	public void setAnySymptoms(boolean Anysymptoms) {
		this.Anysymptoms = Anysymptoms;
	
	}
	public String getFname()
	{
		return this.fname ;
	}
	public String getLname()
	{
		return this.lname;
	}
	public int age()
	{
		return this.age ;
	}
	public boolean Anysymptoms()
	{
		return this.Anysymptoms;
	}
	public boolean CanVaccine(int age , boolean Anysymptoms)
	{
		return (age >= 18 && (Anysymptoms == false));
	}
	public void Leave()
	{
		System.out.println("Thank you for your visit! have a nice day \n");
	}
	public  void VaccinationCost1()
	{
		System.out.println("Your first Dose vaccination costs 20$");
	}
	public void VaccinationCost2()
	{
		System.out.println("Your second Dose vaccination costs 20$");
	}
	
	
	public String toString()
	{
		String rep ="";
		rep += "Name:" + this.fname + " "+ this.lname + " \n age:"+this.age +"\n";
		rep += "CONGRATULATIONS! SUCCESSFULLY VACCINTAED!" ;
		return rep ; 
	}
	
}