package finalproject1;


public class Clinic {
	public Appointment[] appointments;
	public static int count;
	public Clinic()
	{
		this.appointments = new Appointment[100];
		this.count = 0 ;
		
	}
	public Appointment[] getAppointments() {
		return appointments;
	}
	public void setAppointments(Appointment[] appointments) {
		this.appointments = appointments;
	}
    public void add(Appointment appointment)
    {
    	if(this.count == appointments.length)
        	 System.out.println(" no more appoitments for today ");
        	
        	appointments[this.count]= appointment;
        	this.count ++ ;
    }
    public Patient searchAppointment(String fname, String lname)
	{
	  Patient temp ;
	  for(int i = 0 ; i < this.count ; i++)
	  {
		  temp = appointments[i].getPatient();
		  if((temp.getFirstName().equalsIgnoreCase(fname))&&(temp.getLastName().equalsIgnoreCase(lname)))
			  System.out.println("Appointment found");
			  return temp ;
		  
	  }
	  return null ;
	}
    public void editPatientFirstName(String fn, String ln,String newfname)
	{
		Patient patients = searchAppointment(fn,ln) ;
		if(patients != null)
		{
			patients.setFirstName(newfname);
			System.out.println("your first name has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editPatientLastName(String fn, String ln,String newlname)
	{
		Patient patients = searchAppointment(fn,ln) ;
		if(patients != null)
		{
			patients.setLastName(newlname);
			System.out.println("your last name has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editPatientAge(String fn, String ln,int newAge)
	{
		Patient patients = searchAppointment(fn,ln) ;
		if(patients != null)
		{
			patients.setAge(newAge);
			System.out.println("your age has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editPatientSymptom(String fn,String ln,String newSymptom)
	{
		Patient patients = searchAppointment(fn,ln) ;
		if(patients != null)
		{
			patients.setSymptom(newSymptom);
			System.out.println("your Symptom has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	
	public void editPatientVaccination(String fn,String ln,boolean newVaccination)
	{
		Patient patients = searchAppointment(fn,ln) ;
		if(patients != null)
		{
		    patients.setIsVaccinated(newVaccination);
			System.out.println("your vaccination state has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");	
	}
	
	public void deleteAppointment(String fname,String lname)
	{
		Patient temp;
		int foundIndex=0;
		boolean found = false;
		
		for(int i=0; i<count; i++){
			temp= appointments[i].getPatient();
			
			if(temp.getFirstName().toLowerCase().equals(fname.toLowerCase())
				&& temp.getLastName().toLowerCase().equals(lname.toLowerCase()))
			{
				found = true;
				foundIndex = i;
				break;
			}
		}
	if(found)
	{
		for(int i = foundIndex ; i < count ; i++)
		{
			appointments[i]=appointments[i+1];
		}
		(count)--;
		System.out.println("appointment is deleted ");
	}
	else
		System.out.println("Error: appointment does not exist!");
	}
	 public Doctor searchDoctor(String fname, String lname)
		{
		  Doctor temp ;
		  for(int i = 0 ; i < this.count ; i++)
		  {
			  temp = appointments[i].getDoctor();
	 if((temp.getFirstName().equalsIgnoreCase(fname))&&(temp.getLastName().equalsIgnoreCase(lname)))
				  return temp ;
		  }
		  return null ;
		}
    public void editDoctorFirstName(String fn, String ln,String newfname)
	{
		Doctor doctors = searchDoctor(fn,ln) ;
		if(doctors != null)
		{
			doctors.setFirstName(newfname);
			System.out.println("your first name has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editDoctorLastName(String fn, String ln,String newlname)
	{
		Doctor doctors = searchDoctor(fn,ln) ;
		if(doctors != null)
		{
			doctors.setLastName(newlname);
			System.out.println("your last name has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editDoctorAge(String fn, String ln,int newAge)
	{
		Doctor doctors = searchDoctor(fn,ln) ;
		if(doctors != null)
		{
			doctors.setAge(newAge);
			System.out.println("your age has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	public void editDoctorSpeciality(String fn,String ln,String newSpeciality)
	{
		Doctor doctors = searchDoctor(fn,ln) ;
		if(doctors != null)
		{
			doctors.setSpeciality(newSpeciality);
			System.out.println("your speciality has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
	
	
	public void editDoctorVaccination(String fn,String ln,boolean newVaccination)
	{
		Doctor doctors = searchDoctor(fn,ln) ;
		if(doctors != null)
		{
			doctors.setIsVaccinated(newVaccination);
			System.out.println("your vaccination state has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
	}
    public MyDate searchDate(String month,String day,double time)
    {
    	MyDate temp ;
    	 for(int i = 0 ; i < this.count ; i++)
   	  {
   		  temp = appointments[i].getDate();
   		  if((temp.getMonth().equalsIgnoreCase(month))&&(temp.getDay().equalsIgnoreCase(day))&& (temp.getBegHour()==time))
   			  return temp ;
   	  }
   	  return null ;	
    }
    public void editDate(String month,String day,double time,int newmonth,String newday,double newtime)
    {
    	MyDate dates = searchDate(month,day,time) ;
		if(dates != null)
		{
			dates.setMonth(newmonth);
			dates.setDay(newday);
			dates.setBegHour(newtime);
			System.out.println("your date has been successfully updated !");
		}
		else 
			System.out.println("Error: appointment does not exist!");
    }
    @Override
    public String toString()
   {
   String result = "Clinic - > \n" ;
   for(int i=0; i<this.count; i++)
   {
   result += "Client["+202100000+i+"]\n" +
   "patient - >" + appointments[i].getPatient().toString() + "\n" + 
   "doctor - > "  +  appointments[i].getDoctor().toString() + "\n"+
   "date - >   " + appointments[i].getDate().toString() + "\n";
   }
   return result;

   }
} 