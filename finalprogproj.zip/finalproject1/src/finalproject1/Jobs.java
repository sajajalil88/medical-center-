package finalproject1;

public class Jobs {
	public Job[] Jobs;
	public static int count;
    public Jobs()
	{
		this.Jobs = new Job[100];
		this.count = 0 ;
		
	}
	public Job[] getJobs() {
		return this.Jobs;
	}
	public void setJobs(Job[] Jobs) {
		this.Jobs = Jobs;
	}
    public void add(Job newjob)
    {
    	if(this.count == Jobs.length)
        	 System.out.println(" no more appoitments for today ");
        	
        	Jobs[this.count]= newjob;
        	this.count ++ ;
    }
}
